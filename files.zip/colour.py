"""The booth -- the two voices and the logic that decides who says what.

display.render_* is the lap caller's FACTUAL line (a pass, a crash, a stop). This
module wraps two things around that:

  * the PERSONAS -- who is in the booth. The lore speaks in roles ("pbp", "colour");
    here we map those roles to names, so renaming the commentators, or swapping in a
    third, is a one-line change. `voice()` stamps each feed line with its speaker, so
    the whole feed reads as a transcript of two people rather than anonymous calls.

  * the director (Booth) -- a second consumer of the very same event stream the lap
    caller reads. Given a moment it reaches into lore.py for a BIT (a one-liner or a
    multi-turn exchange), prefers the rare relational gold over generic filler, and
    remembers what it has used so nothing repeats in a race. The selection is a
    PRIORITY policy, the same shape as the "is this pass worth calling?" threshold.

The marquee hook is the green-flag conversation: on a lap with no events, a real
booth doesn't fire a one-liner -- it runs a topic and develops it. So next_chatter
advances a multi-turn DISCUSSION a beat at a time across the quiet laps, pausing
when the racing interrupts and resuming after. The lap caller has ALREADY voiced the
factual line by the time a Bit plays, so an overtake Bit is the REACTION to the
move, never a re-call of it.
"""

import random

from drivers import GRID
from lore import (DRIVER_LORE, PAIR_LORE, TRACK_LORE, DISCUSSIONS,
                  CHATTER_RESUME_NAMED, CHATTER_RESUME_GENERIC,
                  GENERIC_INCIDENT, GENERIC_OVERTAKE, GENERIC_PIT,
                  Bit, banter, PODIUM_QUOTES, PODIUM_QUOTE_FALLBACK,
                  # the duo texture -- Benny's register, Phill's reclaim & set-piece
                  BENNY_VERDICT, PHILL_RECLAIM, RUNIN_SETPIECE,
                  LEAD_SETPIECE, RETIRE_SETPIECE,
                  # the calls -- Phill's factual lines, now owned by the booth
                  START_CALLS, OVERTAKE_CALLS, BATTLE_CALLS, BATTLE_REIGNITE,
                  BATTLE_CONTACT, BATTLE_UNDERCUT, SOLO_RETIRE,
                  OVERLIMIT_CALLS, DAMAGE_FAIL_CALLS, COLLISION_CALLS,
                  CAUSE_PHRASE, SOLO_FLOURISH, CONTACT_WORD, PIT_CALLS, UNDERCUT_CALLS,
                  # the stewards -- penalty calls and Benny's colour
                  INVESTIGATION_CALLS, PENALTY_CALLS, PENALTY_SERVED_CALLS,
                  RECLASSIFICATION_CALLS, PENALTY_COLOUR,
                  # the podium interview
                  PODIUM_HANDOFF, PODIUM_QUESTIONS, PODIUM_CLOSER_Q,
                  PODIUM_ANSWER_GENERIC, PODIUM_ANSWERS,
                  # the Countdown to Green -- pooled phrasings + the Objectivism gag
                  PREVIEW_WELCOME, PREVIEW_POLE, PREVIEW_POLE_SOLO, PREVIEW_HANDOFF,
                  PREVIEW_STANDBY, POLE_READ, TRACK_TIP_OPENER, TRACK_TIP_PASS,
                  TRACK_TIP_TYRE, OBJECTIVISM_PREVIEW, WATCH_STRATEGIST, WATCH_CHARGER,
                  # the revamped Countdown -- character pole reads + grid storylines
                  POLE_CHARACTER, PREVIEW_MATCHUP, PREVIEW_WEATHER, PREVIEW_CORNER,
                  # the shows as conversations -- give-and-take for pre/post-race
                  PREVIEW_WELCOME_REACT, PHILL_POLE_RESPONSE, BOOTH_PODIUM_REACT,
                  # the rundown -- a periodic "state of the race" readout
                  RUNDOWN_OPENER, RUNDOWN_LEADER, RUNDOWN_POINTS_EDGE, RUNDOWN_BENNY,
                  # the debrief -- pooled spine + arc-driven "stories of the race"
                  DEBRIEF_WON_DOMINANT, DEBRIEF_WON_FOUGHT, DEBRIEF_WON_CHARGE,
                  DEBRIEF_STORY_Q, DEBRIEF_STORY_OPENER, DEBRIEF_ARC_CONTACT,
                  DEBRIEF_ARC_UNDERCUT, DEBRIEF_ARC_EPIC, DEBRIEF_DOTD,
                  DEBRIEF_CASUALTY_DOUBLE, DEBRIEF_CASUALTY_SINGLE,
                  DEBRIEF_SIGNOFF_PBP, DEBRIEF_SIGNOFF_BENNY,
                  # race control -- the safety car
                  SAFETY_CAR_PBP, SAFETY_CAR_COLOUR, RESTART_PBP, RESTART_COLOUR,
                  DEBRIEF_CAUTION,
                  # race control -- the VSC and the red flag
                  VSC_PBP, VSC_COLOUR, VSC_END_PBP, VSC_END_COLOUR,
                  RED_FLAG_PBP, RED_FLAG_COLOUR, RED_RESTART_PBP, RED_RESTART_COLOUR,
                  DEBRIEF_RED_FLAG)

_DRIVER_BY_NAME = {d.name: d for d in GRID}

# Each driver's teammate (same team) -- so the podium reporter can ask about an
# intra-team scrap by name. Built once from the grid data.
_TEAMMATE = {}
for _d in GRID:
    _mates = [x.name for x in GRID if x.team == _d.team and x.name != _d.name]
    _TEAMMATE[_d.name] = _mates[0] if _mates else None


# Who's in the booth. Roles -> names. Change the strings and the whole feed re-casts
# itself; add a role here (and turns in lore.py) for another voice.
#
# THE BOOTH -- a character bible, because every authored line in lore.py is written
# to these voices. Get the people right and the writing writes itself.
#
#   PHILL  (pbp)  -- the lap caller. NOT a straight-man, NOT a mook: Phill knows his
#       history and his political theory cold, and he can drive a point home himself.
#       But his JOB is the listener. He reads the race for them and, crucially, he
#       draws Benny out -- teeing up the questions a sharp newcomer would ask, about
#       BOTH the philosophy AND the racecraft ("so why does that idea make him brave
#       into Eau Rouge?", "and the undercut works because...?"). He asks not because
#       he doesn't know, but because the audience deserves the answer. Warm, quick,
#       plummy, generous to his co-commentator -- and a bottomless well of enthusiasm.
#
#   BENNY  (colour) -- the sidekick. Ex-racer who reads far too much; explains the
#       theory and the racecraft, thinks half the philosophy is daft and says so, and
#       lands the punchline. Dry where Phill is warm. Knows the cars from the inside.
#
#   SUZE   (report) -- the pit-lane reporter. Podium only; conducts the interviews.
#
# THE TONE -- both men are steeped in Monty Python, the Simpsons, and Douglas Adams,
# and it leaks out of them constantly even as they fight to stay professional. That
# means: deadpan absurdism, the cheerfully bleak aside, the gloriously over-precise
# pedantry, the non-sequitur that lands and is never acknowledged, the sudden swerve
# into the cosmic or the trivial -- and then a brisk snap back to "...anyway, P3 into
# the chicane." The comedy is in the WHIPLASH between high theory, real racecraft, and
# two professionals who cannot quite suppress their own daftness. Never zany for its
# own sake; the funniest line is the one delivered with a perfectly straight face.
PERSONAS = {
    "pbp":    "Phill",    # the lap caller: knows his stuff, serves the listener, irrepressibly keen
    "colour": "Benny",    # the sidekick: ex-racer, dry, well-read, lands the joke
    "report": "Suze",     # the pit-lane reporter: heard only on the podium, conducts the interviews
}
_TAG_WIDTH = max(len(n) for n in PERSONAS.values()) + 1   # room for the colon


def _speaker(role):
    """A role maps to a persona name; anything else (e.g. a driver's name in a
    podium quote) is taken as a literal speaker label."""
    return PERSONAS.get(role, role)


def voice(lap, role, text):
    """One in-race feed line, stamped with its speaker -- so the feed reads as a
    transcript. The speaker label is what tells the voices apart; no '>>' marker."""
    tag = _speaker(role).upper() + ":"
    return f"  L{lap:>2}  {tag:<{_TAG_WIDTH}} {text}"


def voice_show(role, text):
    """A line in a pre/post-race SHOW -- same speaker stamp, but no lap number, since
    the shows happen off the clock (before lights-out / after the flag)."""
    tag = _speaker(role).upper() + ":"
    return f"  {tag:<{_TAG_WIDTH}} {text}"


# Spoken-friendly number words -- the feed says "five laps to go" and "up eleven
# places", never a bare digit, so a text-to-speech engine reads clean prose.
_ONES = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
         "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
         "sixteen", "seventeen", "eighteen", "nineteen"]
_TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy",
         "eighty", "ninety"]
_ORDINAL = {1: "first", 2: "second", 3: "third", 4: "fourth", 5: "fifth",
            6: "sixth", 7: "seventh", 8: "eighth", 9: "ninth", 10: "tenth",
            11: "eleventh", 12: "twelfth", 13: "thirteenth", 14: "fourteenth",
            15: "fifteenth", 16: "sixteenth", 17: "seventeenth", 18: "eighteenth",
            19: "nineteenth", 20: "twentieth"}


def _spell(n):
    """A cardinal number in words, 0-99 -- so a spoken line never shows a digit.
    (Above ninety-nine it falls back to the numeral; no race figure gets there.)"""
    if not isinstance(n, int) or n < 0 or n > 99:
        return str(n)
    if n < 20:
        return _ONES[n]
    tens, ones = divmod(n, 10)
    return _TENS[tens] + (f"-{_ONES[ones]}" if ones else "")


def _ord(n):
    return _ORDINAL.get(n, f"{n}th")


def _at(loc):
    """' at the Parabolica' when we know the corner, '' when we don't."""
    return f" at {loc}" if loc else ""


# How often an ORDINARY pass (no authored rivalry) earns a line about the passer.
# A genuine rivalry always gets called; this keeps us from reacting to every lunge.
PLAIN_OVERTAKE_COLOUR = 0.35

# The duo texture (tuned from real-booth analysis). On a FLAT single-line reaction:
# how often Benny leads with his verdict/causal register, and how often Phill then
# reclaims the call with a flat factual closer -- the even back-and-forth a real
# booth runs. Hand-authored exchanges already do this and are untouched.
BENNY_VERDICT_CHANCE = 0.5
PHILL_RECLAIM_CHANCE = 0.45

# Phill's closing-laps set-piece: in a genuine nail-biter inside the final few laps,
# the lead caller occasionally holds the floor for an extended solo build instead of
# the usual one-line exchange. He is the ONLY voice who does this -- the analysis
# showed the colour man never holds court that long.
SETPIECE_LAPS = 4
SETPIECE_CHANCE = 0.45

# Two cars trading the same place within this many laps reads as ONE ongoing scrap,
# not a string of identical "X passes Y" calls. The booth collapses the flicker.
BATTLE_WINDOW = 3

# How many turns of the running DISCUSSION the booth delivers per quiet lap. Two
# keeps a question-and-answer beat together rather than stranding a tee-up a lap from
# its payoff; the rest carries over to the next quiet lap, so a topic unfolds across
# the green-flag spell and gets interrupted by the racing, like a real booth.
CHATTER_TURNS_PER_LAP = 2

# When the racing PARKS a discussion mid-thread, how the booth picks it back up
# depends on how long it's been parked. A one-lap gap is a seamless continuation
# (no signpost). A gap of at least RESUME_MIN laps means real action came between,
# so the booth re-establishes the subject first ("Back to Derrida and Rorty --").
# A gap longer than RESUME_MAX means the thread is stale -- a retirement, a battle
# and a rundown have all gone by -- so it's dropped and a fresh topic is started
# rather than resurrecting a half-finished thought nobody remembers.
CHATTER_RESUME_MIN = 2
CHATTER_RESUME_MAX = 6

# The closing laps get their OWN register: the booth builds tension toward the flag
# whether or not anything is happening, so the run-in never goes quiet. These lines
# are GENERATED from race state (laps left, the gap), so unlike the authored lull
# pool they can never run dry, and they escalate as the laps tick down.
RUNIN_LAPS = 6

# Run-in phrasings by how close the fight for the lead is. {count} is the spoken
# countdown ("Five laps to go"), {ldr}/{sec} the leader and chaser. Several per
# bucket, and the booth avoids using the same one twice in a row (see _fresh_runin).
_RUNIN = {
    "close": {      # the lead is under real threat -- a nail-biter
        "pbp": ["{count} -- and {sec} is ALL OVER the back of {ldr}!",
                "{count}, and this is on a knife edge -- {sec} right with {ldr}!",
                "{count}, and {sec} has thrown everything at {ldr} -- this is for the win!",
                "{count} -- {sec} filling {ldr}'s mirrors, this is going to the wire!",
                "{count}, and you cannot separate them -- {ldr} and {sec}, nose to tail!"],
        "colour": ["He can see him in the mirrors now. This is going to be desperate.",
                   "One lock-up, one twitch, and it's gone. Edge of your seat.",
                   "Everything on the line here. Nobody is sitting down for this.",
                   "Whoever wants it more over these last few corners. That simple, that brutal.",
                   "Forty years I've done this and my heart's still going. Look at it."],
    },
    "closing": {    # the gap is coming down, but maybe not in time
        "pbp": ["{count} -- {sec} closing on {ldr}, but is there enough road left?!",
                "{count}, and the gap is coming DOWN -- {ldr} will not want to see this!",
                "{count} -- {ldr} still ahead, but {sec} can smell it now!",
                "{count}, and {sec} has found something -- {ldr}'s lead is shrinking!",
                "{count} -- it's {ldr}, but {sec} is reeling them in hand over fist!"],
        "colour": ["Tyres gone off, maybe. Whatever it is, that lead's not safe.",
                   "A few laps ago you'd have called it done. Not any more.",
                   "This could run all the way to the line, you know.",
                   "The maths is tight. A backmarker at the wrong moment and it's on.",
                   "He'll be counting corners now, not laps. Praying for the flag."],
    },
    "clear": {      # a comfortable lead -- but the occasion still lifts the crowd
        "pbp": ["{count}, and {ldr} looks to have this in hand -- but LISTEN to that crowd!",
                "{count} -- {ldr} out on their own up front, and the grandstands are already up!",
                "{count}, and {ldr} is sailing toward it -- the whole place rising to its feet!",
                "{count} -- daylight for {ldr}, and you can hear the roar building already!",
                "{count}, and barring disaster this is {ldr}'s -- the ovation's already starting!"],
        "colour": ["Doesn't matter who's where. You stand and applaud a drive like that.",
                   "Procession or not, that's history happening out front. Up they get.",
                   "They know exactly what they're watching. Whole place on its feet.",
                   "Win like this and the ovation's a formality. Listen to them.",
                   "Nothing left to decide up front now -- just a lap of honour in all but name."],
    },
}

# Weather CALLS -- spoken when the conditions cross a tyre crossover. Like the run-in,
# this is reactive to live state (the booth says it because it just happened), so it's
# inherently fresh; several phrasings per change keep even back-to-back showers varied.
_WEATHER = {
    "rain_begins": {
        "pbp": ["And it's starting to rain! Spots of rain appearing across the circuit!",
                "Rain! Here it comes -- and this track will go greasy in a hurry!",
                "The rain everyone's been watching the skies for -- it's arriving, right now!"],
        "colour": ["Decision time. Slicks are living on borrowed laps from here.",
                   "This is where the strategists earn their keep. Intermediates, and soon.",
                   "The brave stay out a lap too long. The smart are already boxing."],
    },
    "rain_intensifies": {
        "pbp": ["It's really coming down now -- this has become a proper downpour!",
                "The heavens have opened! This is full wet-weather territory now!"],
        "colour": ["Inters won't live in this. They need the full wets, every one of them.",
                   "You can barely see out there. This is survival now, not racing."],
    },
    "rain_eases": {
        "pbp": ["The rain's easing off -- and a dry line just might start to appear!",
                "It's backing off now -- the worst of this may be behind them!"],
        "colour": ["Back to inters, and whoever reads the next few laps right gets the jump.",
                   "Now it flips the other way -- too early onto slicks and you're a passenger."],
    },
    "track_dry": {
        "pbp": ["And the track is dry enough for slicks again -- the gamble is ON!",
                "Slicks are coming back! The racing line has come good!"],
        "colour": ["The crossover is the whole race now. A lap too early and it's chaos.",
                   "First one brave enough for slicks flies -- if they keep it out of the wall."],
    },
}

# Calm-weather AMBIENT -- the filler that makes the user's wish come true: something
# to say even when the weather is lovely and nothing is happening. Generated from the
# temperatures and the sky, bucketed, and never repeated back-to-back from a bucket.
_AMBIENT = {
    "hot": [
        ("Track temperature really climbing now -- well up into the forties.",
         "Hot as that, the tyres give up early. Whoever manages them wins this."),
        ("They're reporting a scorching surface out there this afternoon.",
         "Cooking, that tarmac. The second stint becomes a fight with the rear tyres."),
        ("Heat haze shimmering off the start-finish straight now.",
         "On a track this hot it's not about outright pace -- it's about who's kindest to the rubber."),
        ("The sun is full out and that asphalt is baking.",
         "Thermal degradation, this. They'll be nursing those tyres home, you watch."),
    ],
    "cold": [
        ("A cool, grey afternoon, and a cold track underneath them.",
         "Cold as this, they'll struggle to switch the tyres on. Out-laps will be lurid."),
        ("Air temperature has dropped -- not much warmth in this track at all.",
         "This is when the snaps come from nowhere. No heat in the rubber, no warning."),
        ("Grey skies, a chilly wind down the straight, a cold surface.",
         "Graining weather, this. The fronts will go off long before the rears."),
        ("Barely double figures on the air temperature now.",
         "They'll be weaving like mad on the warm-up laps just to find some grip."),
    ],
    "fair": [
        ("Glorious conditions over the circuit -- barely a cloud up there.",
         "Perfect for it. No hiding place out there today, just racing."),
        ("Warm, settled, a lovely day for a Grand Prix.",
         "Textbook conditions. This is where the genuinely quick ones simply rise."),
        ("Still bone dry, and the skies are staying kind for now.",
         "Long may it last -- though they are keeping an eye on those clouds over the hills."),
        ("A gentle breeze, a warm track, ideal racing weather.",
         "Nothing to blame but yourself in conditions like these. Pure driving."),
        ("Settled and dry, the perfect stage for them.",
         "When it's this benign, the grid order tends to tell the truth. No lottery today."),
    ],
    "greasy": [
        ("Just a few spots in the air, and the track's gone slick and shiny.",
         "Treacherous, this in-between. Slicks underneath them, but no faith in them at all."),
        ("That surface is glistening now -- caught between dry and wet.",
         "Worst of both worlds, this. Too wet to attack, too dry to box. Horrible."),
        ("A greasy sheen across the whole circuit now.",
         "One wrong throttle input and they're gone. Nobody trusts the grip an inch."),
    ],
    "damp": [
        ("Damp all the way round, spray kicking up behind every car.",
         "Intermediate weather through and through. Tip-toe stuff, this."),
        ("A greasy, damp circuit, the inters just about coping.",
         "It's all about commitment now. Hesitate and you're nowhere; overdo it and you're gone."),
        ("Persistent drizzle, the track soaked but not flooded.",
         "Prime intermediate conditions. The feel for it now is everything -- you can't fake this."),
    ],
    "wet": [
        ("Standing water in places now -- great plumes of spray off the back of them!",
         "Anyone who keeps it on the island in this earns a medal, never mind a trophy."),
        ("It is streaming out there, rivers running across the racing line.",
         "Visibility nil, aquaplaning everywhere. This is as hard as their job ever gets."),
        ("Full wets and still struggling -- it is biblical out there now.",
         "At this point it's not racing, it's bravery. Half of them can't see the car ahead."),
    ],
}


class Booth:
    """One per race. Holds the circuit and the memory of which Bits it has used."""

    def __init__(self, track):
        self.circuit = track.circuit if track else ""
        self.used = set()
        self._last_runin = {}                       # (bucket, role) -> last template index used
        self._last_weather = {}                     # change -> (last pbp idx, last colour idx)
        self._ambient_used = {}                     # bucket -> set of pair indices already aired
        self._thread = []                           # remaining turns of the active discussion
        self._thread_lap = 0                         # lap the active thread last played a beat (park/resume gap)
        self._used_threads = set()                  # threads already run this race
        self._last_about = frozenset()              # subjects of the last thread (avoid back-to-back)
        self._battles = {}                          # frozenset(pair) -> {lap, swaps}: collapse trading places
        self._pit_seen = False                       # has ANY pit stop been called yet? (for the "first to blink" moment)

    def _pick(self, bits, tags):
        """Keep Bits whose trigger is in `tags` and that we haven't used, then choose
        one (weighted). Mark it used; return it, or None. Marking is what stops a Bit
        ever repeating within a race."""
        pool = [b for b in bits if b.when in tags and b not in self.used]
        if not pool:
            return None
        chosen = random.choices(pool, weights=[b.weight for b in pool])[0]
        self.used.add(chosen)
        return chosen

    def _pair_any_order(self, a, b, tags):
        """Pair lore that reads either way (a rivalry) -- try both orderings."""
        return (self._pick(PAIR_LORE.get((a, b), []), tags)
                or self._pick(PAIR_LORE.get((b, a), []), tags))

    # --- the calls: Phill's FACTUAL lines, with variety and spoken numbers -----
    # The booth now owns these too (they used to live in display.render_*). Every
    # call is drawn from a deep pool, never repeated back-to-back (_fresh), and
    # every number is spelled, so the lap caller reads as clean as the colour man.
    def call_overtake(self, ov, lap):
        """Phill's call for a completed pass. A re-pass between two cars already
        scrapping is collapsed into one ongoing-battle line, so trading places
        reads as a fight, not a stutter of identical calls."""
        if ov.location == "the start":
            return self._call_start(ov)
        at = _at(ov.location)
        pos_ord = _ord(ov.position)
        pair = frozenset((ov.passer, ov.passed))
        prev = self._battles.get(pair)
        if prev and lap - prev["lap"] <= BATTLE_WINDOW:        # they're at it again
            prev["swaps"] += 1
            prev["lap"] = lap
            bucket = "again" if prev["swaps"] == 1 else "ongoing"
            return self._fresh(f"_battle_{bucket}", BATTLE_CALLS[bucket]).format(
                driver=ov.passer, other=ov.passed, pos=pos_ord, at=at)
        self._battles[pair] = {"lap": lap, "swaps": 0}         # a fresh pass: remember it
        bucket = "lead" if ov.position == 1 else "podium" if ov.position <= 3 else "points"
        return self._fresh(f"_ot_{bucket}", OVERTAKE_CALLS[bucket]).format(
            driver=ov.passer, other=ov.passed, pos=pos_ord, at=at)

    def call_battle_callback(self, ov, laps_since):
        """Phill's callback line for a fight that reignites after going quiet -- the
        director spotted a pair it has seen scrapping before (see director.py). The
        booth only supplies the WORDS; the recognition is the narrative layer's job."""
        at = _at(ov.location)
        return self._fresh("_battle_reignite", BATTLE_REIGNITE).format(
            driver=ov.passer, other=ov.passed, at=at, ago=_spell(laps_since),
            pos=_ord(ov.position))

    def call_battle_contact(self, inc):
        """Phill's lead-in when a fight the director has been tracking ends in contact.
        The mechanical collision call (who's out) follows from call_incident; this just
        names the crash as the climax of a battle, not a random coming-together."""
        at = _at(inc.location)
        return self._fresh("_battle_contact", BATTLE_CONTACT).format(
            driver=inc.driver_name, other=inc.other_name, at=at)

    def call_battle_undercut(self, uc):
        """Phill's call when an undercut settles a fight the cars couldn't resolve on
        track -- a standalone, arc-aware version of call_undercut (it replaces it)."""
        return self._fresh("_battle_undercut", BATTLE_UNDERCUT).format(
            driver=uc.undercutter, other=uc.victim, pos=_ord(uc.position))

    def _call_start(self, ov):
        """The getaway off the line, scaled by how big the launch was."""
        if ov.position == 1:
            bucket = "lead"
        elif ov.places_gained >= 4:
            bucket = "flier"
        elif ov.places_gained >= 2:
            bucket = "good"
        else:
            bucket = "edge"
        return self._fresh(f"_start_{bucket}", START_CALLS[bucket]).format(
            driver=ov.passer, pos=_ord(ov.position), gained=_spell(ov.places_gained))

    def call_incident(self, inc):
        """Phill's call for a mistake, a collision, or a retirement."""
        at = _at(inc.location)
        d = inc.driver_name
        if inc.cause == "over the limit":
            return self._fresh("_inc_depth", OVERLIMIT_CALLS).format(driver=d, at=at)
        if inc.cause == "damage failure":
            return self._fresh("_inc_dmg", DAMAGE_FAIL_CALLS).format(driver=d)
        if inc.cause == "collision":
            if inc.retirement and inc.other_retired:
                bucket = "both_out"
            elif inc.other_retired:
                bucket = "other_out"
            elif inc.retirement:
                bucket = "self_out"
            else:
                bucket = "both_go"
            return self._fresh(f"_col_{bucket}", COLLISION_CALLS[bucket]).format(
                driver=d, other=inc.other_name, at=at,
                severity=inc.severity, word=CONTACT_WORD[inc.severity])
        # solo error: a cause phrasing, then either a retirement tag or a flourish
        phrase = self._fresh(f"_cause_{inc.cause}", CAUSE_PHRASE.get(inc.cause, [inc.cause]))
        if inc.retirement:
            return self._fresh("_solo_retire", SOLO_RETIRE).format(
                driver=d, phrase=phrase, at=at, severity=inc.severity)
        flourish = self._fresh(f"_flour_{inc.severity}", SOLO_FLOURISH[inc.severity])
        return f"{d} {phrase}{at} -- {flourish}"

    def call_pit(self, ps):
        """Phill's call for a pit stop -- spoken, with the stint length in words. The
        very first stop the booth calls all race gets the 'first to blink' drama; once
        a stop's been called, a later driver's first stop is just that -- their first,
        not the race's -- so it must not claim to be 'first' again."""
        onto = f" onto {ps.compound}s" if ps.compound else ""
        stint = _spell(ps.old_stint)
        first_of_race = not self._pit_seen
        self._pit_seen = True
        if ps.stop_number >= 2:
            return self._fresh("_pit_again", PIT_CALLS["again"]).format(
                driver=ps.driver_name, onto=onto, stint=stint, ord=_ord(ps.stop_number))
        if first_of_race:
            return self._fresh("_pit_race_first", PIT_CALLS["race_first"]).format(
                driver=ps.driver_name, onto=onto, stint=stint)
        return self._fresh("_pit_first", PIT_CALLS["first"]).format(
            driver=ps.driver_name, onto=onto, stint=stint)

    def call_undercut(self, uc):
        """Phill's call for an undercut completing -- a pass won in the pit lane."""
        earlier = "a lap" if uc.laps_earlier == 1 else f"{_spell(uc.laps_earlier)} laps"
        bucket = "lead" if uc.position == 1 else "points"
        return self._fresh(f"_uc_{bucket}", UNDERCUT_CALLS[bucket]).format(
            driver=uc.undercutter, other=uc.victim, earlier=earlier, pos=_ord(uc.position))

    # --- the stewards: investigation -> verdict -> serving -> reclassification ---
    def call_investigation(self, inv):
        """Phill notes that race control are looking at something -- the suspense beat
        before any verdict. Falls back to the contact phrasing for any new offence."""
        pool = INVESTIGATION_CALLS.get(inv.offence, INVESTIGATION_CALLS["avoidable contact"])
        return self._fresh(f"_inv_{inv.offence}", pool).format(
            driver=inv.driver_name, other=inv.other_name)

    def call_penalty(self, pen):
        """Phill reads out a verdict. Seconds are spelled for a time penalty; every
        placeholder is supplied so any template in any bucket formats cleanly. The
        verdict ALWAYS names what it's for -- it can land several laps after the
        investigation, so the offence has to travel with it or the listener is lost.
        For contact we name the wronged driver; otherwise the offence speaks for
        itself ('pit-lane speeding', 'track limits', and so on)."""
        pool = PENALTY_CALLS.get(pen.kind, PENALTY_CALLS["time"])
        secs = _spell(int(pen.seconds)) if pen.kind == "time" else ""
        if pen.offence == "avoidable contact" and pen.other_name:
            offence_phrase = f"the contact with {pen.other_name}"
        else:
            offence_phrase = pen.offence or "the incident"
        return self._fresh(f"_pen_{pen.kind}", pool).format(
            driver=pen.driver_name, secs=secs, offence=pen.offence,
            offence_phrase=offence_phrase, other=pen.other_name)

    def call_penalty_served(self, pen):
        """Phill's call as a driver takes a drive-through or stop-go down the lane."""
        return self._fresh("_pen_served", PENALTY_SERVED_CALLS).format(driver=pen.driver_name)

    def call_reclassification(self, name, provisional_pos, official_pos):
        """The flag-time twist: a car classified differently from where it finished on
        the road, once an unserved time penalty is applied. Ordinals spelled."""
        return self._fresh("_reclass", RECLASSIFICATION_CALLS).format(
            driver=name, prov=_ord(provisional_pos), off=_ord(official_pos))

    def for_penalty(self, pen):
        """Benny's dry word on what a verdict MEANS -- the strategic fallout. Warnings
        pass without colour (there's nothing to serve yet)."""
        if pen.kind == "warning":
            return None
        return self._pick(PENALTY_COLOUR, {"penalty"})

    def lights_out(self):
        """The green-flag call -- the SAME words every time, because some moments are
        ritual and the regulars want to hear them. Phill marks the start; the booth
        supplies the circuit name."""
        return f"The lights are off, and we go racing in {self.circuit}!"

    # --- event-triggered colour ---------------------------------------------
    def _duo_texture(self, bit, allow_reclaim=True):
        """Lift a FLAT single-line colour reaction toward the measured duo shape:
        Benny sometimes leads with his own register (a verdict or a causal 'watch
        this'), and Phill sometimes reclaims the call afterwards with a short, FLAT,
        factual closer -- the even caller -> colour -> caller back-and-forth a real
        booth runs. A reaction that is already an authored exchange (more than one
        turn, or a Phill line) is left exactly as written -- those already do this."""
        if bit is None or len(bit.turns) != 1 or bit.turns[0][0] != "colour":
            return bit
        line = bit.turns[0][1]
        if random.random() < BENNY_VERDICT_CHANCE:
            line = self._fresh("_benny_verdict", list(BENNY_VERDICT)) + " " + line
        turns = [("colour", line)]
        if allow_reclaim and random.random() < PHILL_RECLAIM_CHANCE:
            turns.append(("pbp", self._fresh("_phill_reclaim", list(PHILL_RECLAIM))))
        return banter(turns)

    def for_overtake(self, ov):
        """The booth's reaction to a completed pass. A real rivalry is the money
        moment and always plays; the start gets a quick character quip only for the
        drivers who have one; an ordinary pass gets a reaction only sometimes, drawn
        from the passer's own lines or, failing that, a generic one for variety.
        Flat one-liners are given the duo texture; authored exchanges pass through."""
        if ov.location == "the start":
            return self._duo_texture(self._pick(DRIVER_LORE.get(ov.passer, []), {"start"}))
        # Directional: the lore names who passed whom, so only this ordering fits.
        gold = self._pick(PAIR_LORE.get((ov.passer, ov.passed), []), {"overtake"})
        if gold:
            return self._duo_texture(gold)
        if random.random() < PLAIN_OVERTAKE_COLOUR:
            return self._duo_texture(
                self._pick(DRIVER_LORE.get(ov.passer, []), {"overtake", "any"})
                or self._pick(GENERIC_OVERTAKE, {"overtake"}))
        return None

    def for_incident(self, inc):
        """Reaction to a mistake or a retirement -- prefer the retirement-specific
        line when the car is actually out, then the driver's own 'incident' line,
        then a generic one so the colour man never repeats himself across crashes."""
        pool = DRIVER_LORE.get(inc.driver_name, [])
        if inc.retirement:
            return self._duo_texture(
                self._pick(pool, {"retirement"})
                or self._pick(pool, {"incident"})
                or self._pick(GENERIC_INCIDENT, {"incident"})
                or self._pick(pool, {"any"}))
        return (self._pick(pool, {"incident"})
                or self._pick(GENERIC_INCIDENT, {"incident"})
                or self._pick(pool, {"any"}))

    def for_pit(self, ps):
        """The booth's occasional dry word on a pit stop. Most stops pass without
        comment; now and then the driver's own line, or a generic one, gets an airing.
        The caller decides how often to ask (a stop every lap would be noise)."""
        return (self._pick(DRIVER_LORE.get(ps.driver_name, []), {"pit"})
                or self._pick(GENERIC_PIT, {"pit"}))

    # --- the quiet laps: a running DISCUSSION, a beat at a time -------------
    def next_chatter(self, standings, lap):
        """The green-flag conversation. Advance the active discussion by a beat (a
        couple of turns); when it's finished, pick a NEW thread relevant to who's
        actually racing. Returns a list of (role, line) for this lap -- empty only
        if every thread is spent. Because a thread unfolds over several laps and is
        paused (not dropped) when the racing interrupts, it reads as a real
        conversation rather than a one-liner fired and forgotten.

        The catch a real booth handles and a naive one doesn't: when the racing
        parks a thread and we pick it back up laps later, the next authored turn
        ("And out here?") assumes a context the listener has lost. So a resumption
        after a real gap is SIGNPOSTED -- Phill re-names the subject first -- and a
        thread parked too long to be worth resuming is dropped for a fresh one."""
        resumed = False
        if self._thread:
            gap = lap - self._thread_lap
            if gap > CHATTER_RESUME_MAX:
                self._thread = []          # parked too long -- stale, start fresh
            elif gap >= CHATTER_RESUME_MIN:
                resumed = True             # interrupted, but recent enough to pick up -- signpost it

        if not self._thread:
            thread = self._choose_thread(standings)
            if thread is None:
                return []
            self._used_threads.add(thread)
            self._last_about = frozenset(thread.about)
            self._thread = list(thread.turns)
            resumed = False                # a brand-new topic opens itself; no callback needed

        beat = self._thread[:CHATTER_TURNS_PER_LAP]
        self._thread = self._thread[CHATTER_TURNS_PER_LAP:]
        self._thread_lap = lap

        if resumed:
            # Phill re-establishes the subject, THEN the parked beat continues -- so
            # the mid-thread prompt that follows now lands in context again.
            beat = [("pbp", self._resume_opener())] + list(beat)
        return beat

    def _resume_opener(self):
        """A short Phill line re-naming what the booth was discussing before the
        racing cut in, drawn fresh so a busy race doesn't repeat the same re-entry."""
        names = self._spoken_names(self._last_about)
        pool = CHATTER_RESUME_NAMED if names else CHATTER_RESUME_GENERIC
        return self._fresh("_chatter_resume", pool).format(names=names)

    @staticmethod
    def _short(name):
        """A driver's callback name -- the surname a caller would actually say,
        keeping a lowercase particle ('de Beauvoir') and leaving single-name
        thinkers (Plato, Diogenes) whole."""
        parts = name.split()
        if len(parts) == 1:
            return name
        i = len(parts) - 1
        while i > 0 and parts[i - 1][:1].islower():
            i -= 1                          # absorb a particle: '... de Beauvoir'
        return " ".join(parts[i:])

    def _spoken_names(self, about):
        """The thread's subjects as a spoken list of surnames -- '' for a general
        thread, 'Derrida' for one, 'Derrida and Rorty' for two, an Oxford list above."""
        names = [self._short(n) for n in sorted(about)]
        if not names:
            return ""
        if len(names) == 1:
            return names[0]
        if len(names) == 2:
            return f"{names[0]} and {names[1]}"
        return ", ".join(names[:-1]) + f", and {names[-1]}"

    def _choose_thread(self, standings):
        """Pick the next discussion. Prefer threads about a current battle (two cars
        running nose-to-tail) or the leader; let general and track threads in for
        variety; never reuse a thread, and avoid the same subject twice running. If
        the whole pool is spent, recycle it rather than fall silent."""
        running = [s for s in standings if not s.retired]
        if not running:
            return None
        running_names = {s.name for s in running}
        leader = running[0].name
        battling = {frozenset((a.name, b.name)) for a, b in zip(running, running[1:])}

        def candidates():
            scored = []
            for t in DISCUSSIONS:
                if t in self._used_threads:
                    continue
                if t.track and t.track != self.circuit:
                    continue
                if t.about and not set(t.about) <= running_names:
                    continue                            # every named subject must be out there
                score = 1.0
                if t.track == self.circuit:
                    score += 1.5
                if t.about and leader in t.about:
                    score += 3.0
                if len(t.about) >= 2 and frozenset(t.about[:2]) in battling:
                    score += 5.0                        # a live wheel-to-wheel rivalry: talk about it
                if t.about and self._last_about & set(t.about):
                    score *= 0.25                       # just covered this lot -- move on
                scored.append((score, t))
            return scored

        scored = candidates()
        if not scored:                                  # pool spent -- recycle, don't go quiet
            self._used_threads.clear()
            scored = candidates()
        if not scored:
            return None
        return random.choices([t for _, t in scored],
                              weights=[s for s, _ in scored])[0]

    # --- the run to the flag: keep the crowd alive no matter what -----------
    def for_runin(self, standings, lap, total_laps):
        """The closing laps. Build the tension from the live race state -- how many
        laps remain and how big the lead is -- so the run-in is always lively and
        never repeats stale lines. A nail-biter and a procession get different
        words, but BOTH end with the crowd on their feet (that's the whole point:
        the audience should want to stand up whoever wins)."""
        to_go = total_laps - lap
        if not 1 <= to_go <= RUNIN_LAPS:
            return None
        running = [s for s in standings if not s.retired]
        if not running:
            return None
        leader = running[0]
        second = running[1] if len(running) > 1 else None
        margin = second.gap_to_leader if second else None

        if second is not None and margin is not None and margin < 1.2:
            bucket = "close"
        elif second is not None and margin is not None and margin < 4.0:
            bucket = "closing"
        else:
            bucket = "clear"

        count = f"{_spell(to_go).capitalize()} {'lap' if to_go == 1 else 'laps'} to go"
        fmt = {"count": count, "ldr": leader.name, "sec": second.name if second else ""}

        # A genuine nail-biter inside the final few laps is Phill's set-piece: the
        # lead caller holds the floor for an extended, escalating solo build, the way
        # the real booth lets its play-by-play man run when it's on the line. Benny
        # stays out, bar a short word at the end. This is the only place one voice
        # holds court this long -- it's deliberately Phill's, and never Benny's.
        if bucket == "close" and to_go <= SETPIECE_LAPS and random.random() < SETPIECE_CHANCE:
            build = self._fresh_setpiece()
            turns = [("pbp", line.format(**fmt)) for line in build]
            if random.random() < 0.6:
                turns.append(("colour", self._fresh_runin("close", "colour").format(**fmt)))
            return banter(turns)

        phill = self._fresh_runin(bucket, "pbp").format(**fmt)
        benny = self._fresh_runin(bucket, "colour").format(**fmt)
        return banter([("pbp", phill), ("colour", benny)])

    def _fresh_setpiece(self):
        """Pick one of Phill's multi-line set-piece builds, never the same one twice
        running -- so a tense run that triggers it on consecutive laps still escalates
        differently each time."""
        last = self._last_runin.get("_setpiece")
        pool = [i for i in range(len(RUNIN_SETPIECE)) if i != last] or list(range(len(RUNIN_SETPIECE)))
        i = random.choice(pool)
        self._last_runin["_setpiece"] = i
        return RUNIN_SETPIECE[i]

    def _fresh_runin(self, bucket, role):
        """Pick a run-in template, never the same one twice running for this bucket
        and speaker -- so a long procession doesn't echo the same line every lap."""
        options = _RUNIN[bucket][role]
        last = self._last_runin.get((bucket, role))
        pool = [i for i in range(len(options)) if i != last] or list(range(len(options)))
        i = random.choice(pool)
        self._last_runin[(bucket, role)] = i
        return options[i]

    # --- mid-race set-pieces: Phill's extended call on a stop-everything moment ----
    def call_lead_setpiece(self, ov):
        """Phill's escalating build for a pass for the LEAD -- the marquee on-track
        moment, given room to run instead of a single line. Returns the list of pbp
        lines only; the director appends Benny's reaction (for_overtake) after, so the
        teaching payoff lands on the back of the drama. The director decides WHEN this
        fires (rare, capped); the booth just provides the words."""
        build = self._fresh("_lead_setpiece", LEAD_SETPIECE)
        at = _at(ov.location) if ov.location != "the start" else ""
        return [line.format(driver=ov.passer, other=ov.passed, at=at) for line in build]

    def call_retire_setpiece(self, inc):
        """Phill's escalating build for a FRONT-RUNNER's retirement -- a car that was
        in the fight, suddenly gone. Returns the list of pbp lines only; the director
        appends Benny's reaction (for_incident) after."""
        build = self._fresh("_retire_setpiece", RETIRE_SETPIECE)
        return [line.format(driver=inc.driver_name, at=_at(inc.location)) for line in build]

    def for_finish(self, standings):
        """The flag. The winner's moment, always called -- a race never ends on
        silence. Deep pools, picked fresh, so the chequered flag doesn't read the
        same way two races running."""
        running = [s for s in standings if not s.retired]
        if not running:
            return None
        w = running[0]
        phill = self._fresh("_finish_pbp", [
            f"{w.name} takes the chequered flag -- WINS the Grand Prix!",
            f"It's {w.name}! Across the line to take it -- what a result for {w.team}!",
            f"The flag is OUT, and {w.name} has WON it -- a famous day for {w.team}!",
            f"{w.name} brings it home -- victory, and the {w.team} garage erupts!",
            f"And it's {w.name} who takes the win -- they have been imperious today!",
            f"{w.name} crosses the line first -- the chequered flag, and the Grand Prix, is theirs!",
        ])
        benny = self._fresh("_finish_colour", [
            "Get up out of your seats. That is how you win a motor race.",
            "Brilliant. Argue about the philosophy later -- right now, just applaud.",
            "Deserved every inch of that. Cracking drive.",
            "You don't see many better than that. Take a bow.",
            "Whatever you think of their ideas, you cannot fault the driving. Superb.",
            "Flawless when it mattered. That's a winner's afternoon, start to finish.",
            "They thought, they drove, they won. In that order. Lovely to watch.",
        ])
        return banter([("pbp", phill), ("colour", benny)])

    def _fresh(self, key, options):
        """Pick from `options`, avoiding the index used last time for this key -- the
        generic no-immediate-repeat used by the run-in and the flag."""
        last = self._last_runin.get(key)
        pool = [i for i in range(len(options)) if i != last] or list(range(len(options)))
        i = random.choice(pool)
        self._last_runin[key] = i
        return options[i]

    # --- weather: the live conditions, as commentary ------------------------
    def for_weather(self, change):
        """A weather CALL -- the track has crossed a tyre crossover (rain begins,
        intensifies, eases, or dries). Reactive to the moment, so always fresh; the
        booth avoids repeating a phrasing back-to-back across a flickering shower."""
        bucket = _WEATHER.get(change)
        if not bucket:
            return None
        last_p, last_c = self._last_weather.get(change, (None, None))
        pj = [i for i in range(len(bucket["pbp"])) if i != last_p] or list(range(len(bucket["pbp"])))
        cj = [i for i in range(len(bucket["colour"])) if i != last_c] or list(range(len(bucket["colour"])))
        pi, ci = random.choice(pj), random.choice(cj)
        self._last_weather[change] = (pi, ci)
        return banter([("pbp", bucket["pbp"][pi]), ("colour", bucket["colour"][ci])])

    def weather_ambient(self, conditions):
        """Quiet-lap filler GENERATED from the conditions -- temps and sky on a dry
        day, the state of the track on a wet one. This is the answer to 'give them
        something to say even when the weather is calm': there is always a reading to
        remark on, and it drifts lap to lap so it never lands the same way twice."""
        if conditions is None:
            return None
        label = conditions.label
        if label == "dry":
            if conditions.track_temp >= 40:
                bucket = "hot"
            elif conditions.track_temp <= 16:
                bucket = "cold"
            else:
                bucket = "fair"
        else:
            bucket = label                       # "greasy" | "damp" | "wet"
        pairs = _AMBIENT.get(bucket)
        if not pairs:
            return None
        # Air every line in a bucket once before any of them comes round again -- so a
        # long, settled afternoon works through all its remarks instead of echoing two.
        used = self._ambient_used.setdefault(bucket, set())
        if len(used) >= len(pairs):
            used.clear()
        pool = [i for i in range(len(pairs)) if i not in used]
        i = random.choice(pool)
        used.add(i)
        pbp_line, colour_line = pairs[i]
        return banter([("pbp", pbp_line), ("colour", colour_line)])

    # --- the rundown: a periodic state-of-the-race readout ------------------
    def call_rundown(self, standings, lap, total_laps):
        """A 'where everyone stands' readout, GENERATED from the live order so it's
        different every time the order is. The booth rotates between a few structural
        frames (the front of the field / a longer sweep / the points picture) and draws
        the wording fresh from pools, so a recap never lands the same way twice. Returns
        a Bit, or None if there's too little field left to bother."""
        running = [s for s in standings if not s.retired]
        if len(running) < 4:
            return None
        opener = self._fresh("_rundown_open", RUNDOWN_OPENER)
        lead = self._fresh("_rundown_leader", RUNDOWN_LEADER).format(leader=running[0].name)

        frames = ["front", "sweep", "points"]
        last = getattr(self, "_last_rundown_frame", None)
        frame = random.choice([f for f in frames if f != last] or frames)
        self._last_rundown_frame = frame

        depth = 5 if frame == "sweep" else 3
        chasers = running[1:1 + depth]
        parts = []
        for i, s in enumerate(chasers):
            if i == 0:
                parts.append(f"from {s.name}")
            elif i == len(chasers) - 1:
                parts.append(f"and {s.name}")
            else:
                parts.append(f"then {s.name}")
        body = f"{lead}, " + ", ".join(parts)

        if frame == "points":                       # the last-points-place flourish
            p10 = next((s for s in running if s.position == 10), None)
            if p10:
                edge = self._fresh("_rundown_edge", RUNDOWN_POINTS_EDGE).format(
                    name=p10.name, pos=_ord(10))
                body += ". " + edge[0].upper() + edge[1:]

        turns = [("pbp", f"{opener} {body}.")]
        if random.random() < 0.5:                    # a dry tag, about half the time
            turns.append(("colour", self._fresh("_rundown_benny", RUNDOWN_BENNY)))
        return banter(turns)

    # --- race control: the neutralisation family ----------------------------
    def _cause_phrase(self, caution):
        """Turn a terse cause ('collision', 'debris', a driver's name) into something
        the booth can say."""
        c = caution.cause
        if c == "collision":
            return "that collision"
        if c == "debris":
            return "debris on the circuit"
        if c and c not in ("incident", "an incident"):
            return f"{c}'s accident"
        return "an incident on track"

    def call_neutralisation(self, caution):
        """Deployment, dispatched by kind: the safety car, the lighter VSC, or the
        race-stopping red flag."""
        if caution.kind == "vsc":
            return self._call_vsc(caution)
        if caution.kind == "red_flag":
            return self._call_red_flag(caution)
        return self.call_safety_car(caution)

    def call_resumption(self, caution):
        """The return to green, dispatched by kind: a rolling restart, a VSC simply
        lifting, or a standing restart from the grid."""
        if caution.kind == "vsc":
            return self._call_vsc_end(caution)
        if caution.kind == "red_flag":
            return self._call_red_restart(caution)
        return self.call_restart(caution)

    def call_safety_car(self, caution):
        """The deployment call -- the biggest headline a race throws up. Phill scrambles
        it; Benny reads the strategic carnage (gaps wiped, the cheap-stop rush)."""
        return banter([
            ("pbp", self._fresh("_sc_pbp", SAFETY_CAR_PBP).format(cause_phrase=self._cause_phrase(caution))),
            ("colour", self._fresh("_sc_colour", SAFETY_CAR_COLOUR)),
        ])

    def call_restart(self, caution):
        """The rolling restart -- green again, the field nose to tail. The crescendo."""
        return banter([
            ("pbp", self._fresh("_restart_pbp", RESTART_PBP)),
            ("colour", self._fresh("_restart_colour", RESTART_COLOUR)),
        ])

    def _call_vsc(self, caution):
        """The full-course yellow -- a lighter neutralisation. Gaps held, just slower."""
        return banter([
            ("pbp", self._fresh("_vsc_pbp", VSC_PBP).format(cause_phrase=self._cause_phrase(caution))),
            ("colour", self._fresh("_vsc_colour", VSC_COLOUR)),
        ])

    def _call_vsc_end(self, caution):
        """The VSC lifting -- back to green with the order untouched, no shuffle."""
        return banter([
            ("pbp", self._fresh("_vsc_end_pbp", VSC_END_PBP)),
            ("colour", self._fresh("_vsc_end_colour", VSC_END_COLOUR)),
        ])

    def _call_red_flag(self, caution):
        """The red flag -- the race STOPPED. The loudest call there is, and the free
        tyre change is the story Benny reaches for."""
        return banter([
            ("pbp", self._fresh("_red_pbp", RED_FLAG_PBP).format(cause_phrase=self._cause_phrase(caution))),
            ("colour", self._fresh("_red_colour", RED_FLAG_COLOUR)),
        ])

    def _call_red_restart(self, caution):
        """The standing restart from the grid -- a second start, launch lottery and all."""
        return banter([
            ("pbp", self._fresh("_red_restart_pbp", RED_RESTART_PBP)),
            ("colour", self._fresh("_red_restart_colour", RED_RESTART_COLOUR)),
        ])

    # --- the shows: off-clock segments before and after the race ------------
    def preview(self, quali, track):
        """The 'Countdown to Green'. A branded open (the Political Philosophy Racing
        League, every week), then a MIDDLE built from a menu of segments and varied
        race to race -- the pole read in character, the grid's own storylines (rivals
        lining up to renew an old grudge), and a rotating bit of scene-setting -- then
        a clean close into the lights. The substance changes weekly, not just the
        wording, because the storylines are generated from THIS grid and THIS track."""
        qualifiers = [d for d, lap, ok in quali if ok]
        # OPEN -- the brand, always, then Benny's warm word so it's two people talking.
        turns = [("pbp", self._fresh("_prev_welcome", PREVIEW_WELCOME).format(
            circuit=track.circuit, name=track.name))]
        if random.random() < 0.6:
            turns.append(("colour", self._fresh("_prev_welcome_react", PREVIEW_WELCOME_REACT)))

        # MIDDLE -- the pole leads the grid talk (natural broadcast order); the
        # storylines, the extra and the gag shuffle behind it for variety. Order
        # varies; the open and the close still bracket it, so coherence holds.
        middle = self._preview_segments(qualifiers, track)
        if middle:
            head, tail = middle[0], middle[1:]
            random.shuffle(tail)
            middle = [head] + tail
        for seg in middle:
            turns.extend(seg)

        # CLOSE -- Phill throws to Benny for the watch-points, then brings up the grid.
        turns.append(("pbp", self._fresh("_prev_handoff", PREVIEW_HANDOFF)))
        turns.append(("colour", self._track_tips(track)))
        turns.append(("pbp", self._fresh("_prev_standby", PREVIEW_STANDBY)))
        return turns

    def _preview_segments(self, qualifiers, track):
        """The menu. Always in: the pole (the centrepiece) and the Objectivism
        write-off (the running gag). The heart: up to two grid storylines -- real
        rivalries lining up near each other. Then ONE rotating extra for texture
        (track history, the weather outlook, a name to watch, or a key-corner call),
        so the show's substance differs week to week, not just its phrasing."""
        segments = []
        if qualifiers:
            segments.append(self._seg_pole(qualifiers))
        segments.extend(self._grid_storylines(qualifiers))     # 0-2, the centrepiece

        extras = []
        hist = self._pick(TRACK_LORE.get(self.circuit, []), {"any"})
        if hist:
            extras.append(list(hist.turns))
        wx = self._seg_weather(track)
        if wx:
            extras.append(wx)
        watch = self._seg_watch(qualifiers)
        if watch:
            extras.append(watch)
        scene = self._seg_scene(track)
        if scene:
            extras.append(scene)
        if extras:
            segments.append(random.choice(extras))            # one extra -- keep it tight

        segments.append(list(random.choice(OBJECTIVISM_PREVIEW)))  # the gag, always
        return segments

    def _seg_pole(self, qualifiers):
        """The pole block: Phill announces the front row, Benny READS the pole-sitter
        in character (who they are, not just their numbers), Phill sometimes takes the
        ball back. The centrepiece of the grid, given the weight it deserves."""
        pole = qualifiers[0]
        block = []
        if len(qualifiers) > 1:
            block.append(("pbp", self._fresh("_prev_pole", PREVIEW_POLE).format(
                pole=pole.name, team=pole.team, second=qualifiers[1].name)))
        else:
            block.append(("pbp", self._fresh("_prev_pole_solo", PREVIEW_POLE_SOLO).format(
                pole=pole.name, team=pole.team)))
        read = self._pole_read(pole)
        if random.random() < BENNY_VERDICT_CHANCE:
            read = self._fresh("_benny_verdict", list(BENNY_VERDICT)) + " " + read
        block.append(("colour", read))
        if random.random() < 0.5:
            block.append(("pbp", self._fresh("_prev_pole_resp", PHILL_POLE_RESPONSE)))
        return block

    def _grid_storylines(self, qualifiers):
        """The grid's own drama. Scan the known rivalries; for any pair both on the
        grid, WEIGHT by how high up and how close together they start -- a feud you'll
        actually SEE is worth more than one buried in the order -- then SAMPLE up to
        two (never featuring one driver twice). Sampling, not strict top-two, keeps the
        front-row rivalry favoured without letting the fastest pair headline every
        single week. This is what makes the Countdown specific to the day."""
        pos = {d.name: i + 1 for i, d in enumerate(qualifiers)}
        weighted = []
        for pair in PREVIEW_MATCHUP:
            if not pair <= set(pos):
                continue
            ranked = sorted(pos[n] for n in pair)
            ahead_pos, behind_pos = ranked[0], ranked[1]
            gap = behind_pos - ahead_pos
            front = (ahead_pos + behind_pos) / 2.0
            weight = max(0.3, 8.0 - gap * 0.7 - front * 0.35)   # close + front = likelier, never zero
            weighted.append((weight, pair, ahead_pos, behind_pos))

        out, used = [], set()
        while weighted and len(out) < 2:
            total = sum(w for w, *_ in weighted)
            r = random.uniform(0, total)
            upto = 0.0
            for idx, (w, pair, ahead_pos, behind_pos) in enumerate(weighted):
                upto += w
                if upto >= r:
                    chosen = idx
                    break
            else:
                chosen = len(weighted) - 1
            _w, pair, ahead_pos, behind_pos = weighted.pop(chosen)
            if used & pair:
                continue
            ahead = next(n for n in pair if pos[n] == ahead_pos)
            behind = next(n for n in pair if pos[n] == behind_pos)
            bit = self._fresh(f"_matchup_{tuple(sorted(pair))}", PREVIEW_MATCHUP[pair])
            seg = [(role, line.format(ahead=ahead, behind=behind,
                                      ahead_ord=_ord(ahead_pos), behind_ord=_ord(behind_pos)))
                   for role, line in bit.turns]
            out.append(seg)
            used |= pair
        return out

    def _seg_weather(self, track):
        """A forecast beat, scaled to the track's rain_chance -- flagged when it
        matters, skipped about half the time when the day's plainly dry."""
        rc = getattr(track, "rain_chance", 0.0)
        bucket = "likely" if rc >= 0.30 else "possible" if rc >= 0.15 else "dry"
        if bucket == "dry" and random.random() < 0.5:
            return None
        return [("colour", self._fresh(f"_prev_wx_{bucket}", PREVIEW_WEATHER[bucket]))]

    def _seg_watch(self, qualifiers):
        """A name to watch from down the order -- the existing buried-charger /
        strategist read, presented as its own preview segment."""
        watch = self._watch_name(qualifiers)
        return [("colour", watch)] if watch else None

    def _seg_scene(self, track):
        """A key-corner callout, naming where this circuit tends to be decided."""
        corners = [c.name for c in getattr(track, "corners", []) if getattr(c, "overtaking", False)]
        if not corners:
            return None
        return [("colour", self._fresh("_prev_corner", PREVIEW_CORNER).format(
            corner=random.choice(corners)))]

    def debrief(self, summary, history, track, memory=None):
        """The post-race show. Its spine is now the race's ACTUAL arcs (read from the
        director's RaceMemory): the fights that defined the race and how they ended --
        a clash, an undercut, an epic that ran to the flag. That makes the show the
        PAYOFF of what we watched, and different every weekend, because the arcs are.
        Every framing line is now drawn fresh from a pool, so the booth stops repeating
        itself. Falls back gracefully (skips the stories beat) if no memory is given."""
        s = summary
        turns = [("pbp", f"And that's the chequered flag at {s.circuit} -- "
                         f"{s.winner} wins it for {s.team}!")]

        # How it was won -- pooled, so the same KIND of win doesn't draw the same words.
        if s.winner_from == 1 and s.lead_changes == 0:
            won = self._fresh("_debrief_won_dom", DEBRIEF_WON_DOMINANT).format(winner=s.winner)
        elif s.winner_from == 1:
            won = self._fresh("_debrief_won_fought", DEBRIEF_WON_FOUGHT).format(winner=s.winner)
        else:
            won = self._fresh("_debrief_won_charge", DEBRIEF_WON_CHARGE).format(
                winner=s.winner, start=_ord(s.winner_from))
        if random.random() < BENNY_VERDICT_CHANCE:      # Benny opens with his own register
            won = self._fresh("_benny_verdict", list(BENNY_VERDICT)) + " " + won
        turns.append(("colour", won))

        # The stories of the race -- the defining fights, read from the arcs the
        # director tracked. THIS is the memory wiring: the show recalls what we watched,
        # framed by how each fight ended. It also covers the strategy beat (an undercut
        # that settled a battle), so there's no separate canned strategy line any more.
        stories = self._race_stories(memory)
        if stories:
            turns.append(("pbp", self._fresh("_debrief_story_q", DEBRIEF_STORY_Q)))
            turns.extend(stories)

        # The drive of the day.
        if s.drive_of_the_day:
            name, gained = s.drive_of_the_day
            gain = f"{_spell(gained)} place{'s' if gained != 1 else ''}"
            turns.append(("pbp", "Drive of the day?"))
            turns.append(("colour", self._fresh("_debrief_dotd",
                          DEBRIEF_DOTD).format(name=name, gain=gain)))

        # Where it went wrong.
        if s.double_dnfs:
            a, b, _lap, _loc = s.double_dnfs[0]
            turns.append(("colour", self._fresh("_debrief_cas_double",
                          DEBRIEF_CASUALTY_DOUBLE).format(a=a, b=b)))
        elif s.retirements:
            turns.append(("colour", self._fresh("_debrief_cas_single",
                          DEBRIEF_CASUALTY_SINGLE).format(name=s.retirements[0][0])))

        # Race control, if it had its say -- a red flag is its own headline; any other
        # neutralisation gets the general nod.
        if getattr(s, "red_flag", False):
            turns.append(("colour", self._fresh("_debrief_red", DEBRIEF_RED_FLAG)))
        elif getattr(s, "cautions", 0):
            turns.append(("colour", self._fresh("_debrief_caution", DEBRIEF_CAUTION)))

        # The podium interview -- Suze and the drivers ONLY. A real broadcast never
        # has the booth talking over a podium answer; they wait, then pick it up.
        podium = s.podium[:3]
        if podium:
            turns.append(random.choice(PODIUM_HANDOFF))
            final = history[-1].standings
            for pos, name, team in podium:
                turns.extend(self._interview(name, pos, team, final, history, s))
            turns.append(("report", "Plenty to chew on -- back to you in the booth."))
            turns.append(self._fresh_podium_react())  # NOW the booth lands on it, once, after the handback

        # Sign-off -- pooled both sides now.
        turns.append(("pbp", self._fresh("_debrief_signoff",
                      DEBRIEF_SIGNOFF_PBP).format(circuit=s.circuit)))
        turns.append(("colour", self._fresh("_debrief_signoff_b", DEBRIEF_SIGNOFF_BENNY)))
        return turns

    def _arc_score(self, arc):
        """How memorable a fight was: trades and reignitions, a bonus for a dramatic
        ending, and more weight the closer to the front it was fought."""
        score = arc.exchanges * 2 + arc.reignitions * 3
        if arc.resolved == "contact":
            score += 6
        elif arc.resolved == "undercut":
            score += 4
        score += max(0, 6 - arc.position)
        return score

    def _race_stories(self, memory):
        """Pick the two most memorable fights from the race's arcs and frame each by
        how it ENDED -- a clash, an undercut, or an epic that ran on. Returns colour
        turns, or [] when there's no memory or nothing worth retelling."""
        if memory is None:
            return []
        arcs = [a for a in memory.arcs.values()
                if a.exchanges >= 1 or a.reignitions >= 1 or a.resolved in ("contact", "undercut")]
        if not arcs:
            return []
        arcs.sort(key=self._arc_score, reverse=True)
        turns = [("colour", self._fresh("_debrief_story_open", DEBRIEF_STORY_OPENER))]
        for arc in arcs[:2]:
            winner = arc.leader or next(iter(arc.pair))
            others = arc.pair - {winner}
            loser = next(iter(others)) if others else winner
            if arc.resolved == "contact":
                line = self._fresh("_debrief_arc_contact",
                                   DEBRIEF_ARC_CONTACT).format(a=winner, b=loser)
            elif arc.resolved == "undercut":
                line = self._fresh("_debrief_arc_undercut",
                                   DEBRIEF_ARC_UNDERCUT).format(winner=winner, loser=loser)
            else:
                line = self._fresh("_debrief_arc_epic",
                                   DEBRIEF_ARC_EPIC).format(a=winner, b=loser)
            turns.append(("colour", line))
        return turns

    # --- show helpers -------------------------------------------------------
    def _pole_read(self, d):
        """Benny's read on the pole-sitter. In character first -- WHO this is, the
        politics carried by the fact of the pole (POLE_CHARACTER) -- and only if this
        driver has no character line do we fall back to the stat-bucket read, so the
        front of the grid always means something about the philosopher sitting on it."""
        char = POLE_CHARACTER.get(d.name)
        if char:
            return self._fresh(f"_pole_char_{d.name}", char).format(name=d.name)
        if d.strategy < 0.35:
            bucket = "quick_no_head"
        elif d.racecraft >= 0.78:
            bucket = "racer"
        elif d.tire_management >= 0.78:
            bucket = "tyre"
        else:
            bucket = "plain"
        return self._fresh(f"_pole_{bucket}", POLE_READ[bucket]).format(name=d.name)

    def _watch_name(self, qualifiers):
        """A name to watch from outside the top five -- a buried strategist or a
        charger who won't stay put. Phrasing drawn fresh from a pool."""
        back = qualifiers[5:]
        if not back:
            return None
        strat = max(back, key=lambda d: d.strategy)
        if strat.strategy >= 0.7:
            return self._fresh("_watch_strat", WATCH_STRATEGIST).format(
                name=strat.name, start_ord=_ord(qualifiers.index(strat) + 1))
        charger = max(back, key=lambda d: d.racecraft)
        if charger.racecraft >= 0.78:
            return self._fresh("_watch_charger", WATCH_CHARGER).format(
                name=charger.name, start_ord=_ord(qualifiers.index(charger) + 1))
        return None

    def _track_tips(self, track):
        """What to watch, generated from the track's own numbers (so it stays true if
        you retune the circuit) -- but the phrasing for each point is drawn fresh from a
        pool, so the same circuit never reads its watch-points the same way twice. The
        Objectivism write-off is no longer tacked on here; it's its own beat now."""
        d = track.overtaking_difficulty
        pass_bucket = "hard" if d >= 0.30 else "easy" if d <= 0.06 else "fair"
        clauses = [self._fresh(f"_tip_pass_{pass_bucket}", TRACK_TIP_PASS[pass_bucket])]
        w = track.tyre_wear
        if w >= 1.2:
            clauses.append(self._fresh("_tip_tyre_high", TRACK_TIP_TYRE["high"]))
        elif w <= 0.6:
            clauses.append(self._fresh("_tip_tyre_low", TRACK_TIP_TYRE["low"]))
        return random.choice(TRACK_TIP_OPENER) + "; ".join(clauses) + "."

    def _podium_quote(self, name):
        pool = PODIUM_QUOTES.get(name) or PODIUM_QUOTE_FALLBACK
        return random.choice(pool) if pool else None

    # --- the podium interview -----------------------------------------------
    def _interview(self, name, pos, team, final, history, summary):
        """One driver's interview: a few RACING questions earned by what actually
        happened to them, each answered in their own voice, then the philosophy
        quote as the closer. The winner gets two angles; the others get one. The
        booth stays OUT of it -- a podium interview is Suze and the driver alone, the
        way a real broadcast runs it. The booth has its say once Suze hands back."""
        turns = []
        angles = self._interview_angles(name, pos, final, history, summary)
        n_blocks = 2 if pos == 1 else 1
        for angle in angles[:n_blocks]:
            turns.extend(self._interview_beats(angle, name, final))
        quote = self._podium_quote(name)              # the closer: their philosophy line
        if quote:
            key = "winner" if pos == 1 else "other"
            turns.append(("report", self._fresh(f"_closer_{key}", PODIUM_CLOSER_Q[key])))
            turns.append((name, quote))
        return turns

    def _fresh_podium_react(self):
        """The booth's one reflection on the podium, played AFTER Suze hands back --
        never over an answer. No immediate repeat. A (role, line) turn, so it can
        come from either Phill or Benny."""
        last = self._last_runin.get("_podium_react")
        pool = [i for i in range(len(BOOTH_PODIUM_REACT)) if i != last] or list(range(len(BOOTH_PODIUM_REACT)))
        i = random.choice(pool)
        self._last_runin["_podium_react"] = i
        return BOOTH_PODIUM_REACT[i]

    def _interview_angles(self, name, pos, final, history, summary):
        """Which questions THIS driver has earned, most race-defining first. Always
        ends with a generic opener so there's never nothing to ask."""
        st = next((x for x in final if x.name == name), None)
        gained = (st.grid_position - st.position) if st else 0
        angles = []
        if pos == 1 and st and st.grid_position == 1 and summary.lead_changes == 0:
            angles.append("pole_to_win")              # led every lap from pole
        if gained >= 4:
            angles.append("charge")                   # came through the field
        mate = _TEAMMATE.get(name)
        if mate:
            mate_st = next((x for x in final if x.name == mate), None)
            if mate_st and not mate_st.retired and abs(mate_st.position - pos) <= 3:
                angles.append("teammate")             # a genuine intra-team scrap
        if any(getattr(r, "weather_change", None) for r in history):
            angles.append("weather")                  # they raced a tyre gamble
        if st and (st.damage > 0.02 or self._survived_contact(name, history)):
            angles.append("survival")                 # carried damage / survived contact
        angles.append("win_open")                     # the always-available fallback
        return angles

    def _interview_beats(self, angle, name, final):
        """The (reporter question, driver answer) turns for one angle. The teammate
        angle naturally runs two beats -- the scrap, then the team-orders follow-up."""
        if angle == "teammate":
            mate = _TEAMMATE.get(name) or "your teammate"
            q1 = self._fresh("_q_teammate", PODIUM_QUESTIONS["teammate"]).format(mate=mate)
            q2 = self._fresh("_q_team_orders", PODIUM_QUESTIONS["team_orders"])
            return [("report", q1), (name, self._answer(name, "teammate")),
                    ("report", q2), (name, self._answer(name, "team_orders"))]
        st = next((x for x in final if x.name == name), None)
        gained = max((st.grid_position - st.position) if st else 0, 0)
        start_ord = _ord(st.grid_position if st else 1)
        q = self._fresh(f"_q_{angle}", PODIUM_QUESTIONS[angle]).format(
            gained=_spell(gained), start_ord=start_ord)
        return [("report", q), (name, self._answer(name, angle))]

    def _answer(self, name, angle):
        """The driver's reply: their authored line for this angle if they have one,
        else the generic floor. Overrides get per-driver no-repeat memory; the floor
        is keyed by angle ALONE, so two finishers never echo the same floor line in
        the one ceremony."""
        override = PODIUM_ANSWERS.get(name, {}).get(angle)
        if override:
            return self._fresh(f"_ans_ovr_{name}_{angle}", override)
        pool = PODIUM_ANSWER_GENERIC.get(angle) or PODIUM_ANSWER_GENERIC["win_open"]
        return self._fresh(f"_ans_gen_{angle}", pool)

    def _survived_contact(self, name, history):
        """Was this driver in a collision they walked away from? (Sets up the
        'you took a knock and still finished' question.)"""
        for r in history:
            for inc in r.incidents:
                if inc.cause != "collision":
                    continue
                if inc.driver_name == name and not inc.retirement:
                    return True
                if inc.other_name == name and not inc.other_retired:
                    return True
        return False
